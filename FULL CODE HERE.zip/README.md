# random_quiz

start the program and it will take random quiz options from internet 

in the end it will count the correct and incorect answers
